# Run: gtkwave vadd-selected.vcd --script=view-vadd.tcl
set requested [list {selected.TOP__clock} {selected.TOP__SimTop__difftest_timer} {selected.TOP__SimTop__l_soc__core_with_l2__core__backend__inner_ctrlBlock__decode__io_in_0_valid} {selected.TOP__SimTop__l_soc__core_with_l2__core__backend__inner_ctrlBlock__decode__io_in_0_ready} {selected.TOP__SimTop__l_soc__core_with_l2__core__backend__inner_ctrlBlock__decode__io_in_0_bits_pc} {selected.TOP__SimTop__l_soc__core_with_l2__core__backend__inner_ctrlBlock__decode__io_in_0_bits_instr} {selected.TOP__SimTop__l_soc__core_with_l2__core__backend__inner_ctrlBlock__rob__io_enq_req_0_valid} {selected.TOP__SimTop__l_soc__core_with_l2__core__backend__inner_ctrlBlock__rob__io_enq_req_0_bits_pc} {selected.TOP__SimTop__l_soc__core_with_l2__core__backend__inner_vfExuBlock__exus_2__VialuFix__io_in_valid} {selected.TOP__SimTop__l_soc__core_with_l2__core__backend__inner_vfExuBlock__exus_2__VialuFix__io_in_ready} {selected.TOP__SimTop__l_soc__core_with_l2__core__backend__inner_vfExuBlock__exus_2__VialuFix__io_in_bits_data_src_0} {selected.TOP__SimTop__l_soc__core_with_l2__core__backend__inner_vfExuBlock__exus_2__VialuFix__io_in_bits_data_src_1} {selected.TOP__SimTop__l_soc__core_with_l2__core__backend__inner_vfExuBlock__exus_2__VialuFix__io_out_valid} {selected.TOP__SimTop__l_soc__core_with_l2__core__backend__inner_vfExuBlock__exus_2__VialuFix__io_out_ready} {selected.TOP__SimTop__l_soc__core_with_l2__core__backend__inner_vfExuBlock__exus_2__VialuFix__io_out_bits_res_data} {selected.TOP__SimTop__l_soc__core_with_l2__core__backend__inner_ctrlBlock__rob__io_commits_isCommit} {selected.TOP__SimTop__l_soc__core_with_l2__core__backend__inner_ctrlBlock__rob__io_commits_commitValid_0} {selected.TOP__SimTop__l_soc__core_with_l2__core__backend__inner_ctrlBlock__rob__io_commits_info_0_debug_pc}]
set found [list]
set n [gtkwave::getNumFacs]
foreach requested_name $requested {
  for {set i 0} {$i < $n} {incr i} {
    set name [gtkwave::getFacName $i]
    set base [regsub {\[[^]]+\]$} $name ""]
    if {$base eq $requested_name} {lappend found $name; break}
  }
}
puts "stage1 signals selected: [llength $found]"
gtkwave::addSignalsFromList $found
gtkwave::setZoomRangeTimes 8420 8470
gtkwave::setMarker 8463
gtkwave::setNamedMarker A 8424 "decode"
gtkwave::setNamedMarker B 8428 "ROB"
gtkwave::setNamedMarker C 8463 "ALU-in"
gtkwave::setNamedMarker D 8464 "ALU-out"
gtkwave::setNamedMarker E 8466 "commit"
puts "stage1 waveform view ready"
if {[info exists ::env(KKS_WAVE_SMOKE_TEST)]} {
  exit 0
}
